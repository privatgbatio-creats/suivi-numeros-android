MILLIONNAIRE — Projet Android

Ce projet transforme le programme HTML Millionnaire en application Android hors ligne.
Les données sont conservées localement dans le stockage WebView de l'application.

Compilation automatique :
1. Le dossier du projet est compilé par GitHub Actions.
2. Le fichier APK debug est produit sous :
   app/build/outputs/apk/debug/app-debug.apk
3. Le workflow GitHub publie le fichier sous forme d'artefact téléchargeable.

Configuration :
- Nom de l'application : Millionnaire
- Identifiant Android : ci.millionnaire.app
- Android minimum : 6.0 (API 23)
- Compilation : Android Gradle Plugin 8.7.3 / Gradle 8.9 / JDK 17

Diagnostic build: applicationId ci.millionnaire.app.diagnostic, label Millionnaire TEST.
