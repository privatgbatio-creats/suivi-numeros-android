PROJET ANDROID — SUIVI DES NUMÉROS

Ce dossier contient le projet Android Studio qui intègre le fichier HTML v3 dans une application Android WebView.
L'application utilise le stockage local WebView (DOM Storage) pour conserver les données sur le téléphone.

Pour générer l'APK :
1. Ouvrir ce dossier dans Android Studio (version récente).
2. Laisser Android Studio synchroniser Gradle et installer les composants Android SDK demandés.
3. Choisir Build > Build Bundle(s) / APK(s) > Build APK(s).
4. L'APK de test sera normalement dans app/build/outputs/apk/debug/app-debug.apk.

IMPORTANT : cet environnement ne contient pas Android SDK, Gradle ni ADB. L'APK n'a donc pas pu être compilé ni testé ici. Ce projet source n'est pas lui-même un APK installable.
